package dao;

import entidade.Cliente;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.List;

public class ClienteDAO {
    private static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

    public void salvar(Cliente cliente) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.save(cliente);
            tx.commit();
            System.out.println("Cliente salvo com sucesso!");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Erro ao salvar cliente: " + e.getMessage());
        }
    }

    public List<Cliente> listar() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from Cliente", Cliente.class).list();
        } catch (Exception e) {
            System.err.println("Erro ao listar clientes: " + e.getMessage());
            return null;
        }
    }

    public void atualizar(Cliente cliente) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.update(cliente);
            tx.commit();
            System.out.println("Cliente atualizado com sucesso!");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Erro ao atualizar cliente: " + e.getMessage());
        }
    }

    public void excluir(int id) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            Cliente cliente = session.get(Cliente.class, id);
            if (cliente != null) {
                tx = session.beginTransaction();
                session.delete(cliente);
                tx.commit();
                System.out.println("Cliente excluído com sucesso!");
            } else {
                System.out.println("Cliente não encontrado.");
            }
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            System.err.println("Erro ao excluir cliente: " + e.getMessage());
        }
    }

    public Cliente buscarPorId(int id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Cliente.class, id);
        } catch (Exception e) {
            System.err.println("Erro ao buscar cliente: " + e.getMessage());
            return null;
        }
    }
}